</body>
<?php
/*Footer Function wp*/ 
wp_footer(); 
?>
</html>