<?php
//Silent is Gold