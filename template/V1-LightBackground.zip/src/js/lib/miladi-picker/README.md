DCalendar
=========

JQuery calendar plugin plus date picker for input fields.
