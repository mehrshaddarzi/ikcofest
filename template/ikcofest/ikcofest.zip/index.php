<?php
get_header();
get_template_part('layout/home');
get_footer();